package com.bonitasoft.rest.context;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;

import groovy.json.JsonBuilder
import groovy.json.JsonException;
import groovy.json.JsonSlurper;

import org.slf4j.Logger
import org.slf4j.LoggerFactory

import javax.servlet.http.HttpServletRequest
import javax.servlet.http.HttpServletResponse

import org.apache.http.HttpHeaders


import org.bonitasoft.engine.api.APIClient;
import org.bonitasoft.engine.api.BusinessDataAPI;
import org.bonitasoft.engine.api.ProcessAPI;
import org.bonitasoft.engine.bpm.data.ArchivedDataInstance;
import org.bonitasoft.engine.bpm.data.ArchivedDataNotFoundException;
import org.bonitasoft.engine.bpm.data.DataInstance;
import org.bonitasoft.engine.bpm.data.DataNotFoundException;
import org.bonitasoft.engine.bpm.flownode.ActivityInstance;
import org.bonitasoft.engine.bpm.flownode.ArchivedActivityInstance;
import org.bonitasoft.engine.bpm.process.ArchivedProcessInstance;
import org.bonitasoft.engine.bpm.process.ProcessInstance;
import org.bonitasoft.engine.bdm.Entity;
import org.bonitasoft.engine.bdm.dao.BusinessObjectDAO;
import org.bonitasoft.engine.business.data.BusinessDataReference;
import org.bonitasoft.engine.business.data.MultipleBusinessDataReference;
import org.bonitasoft.engine.business.data.SimpleBusinessDataReference;
import org.bonitasoft.engine.session.APISession;
import org.bonitasoft.web.extension.ResourceProvider
import org.bonitasoft.web.extension.rest.RestApiResponse
import org.bonitasoft.web.extension.rest.RestApiResponseBuilder

import com.bonitasoft.web.extension.rest.RestAPIContext
import com.bonitasoft.web.extension.rest.RestApiController

class GetContext implements RestApiController {

	private static final Logger logger = LoggerFactory.getLogger(GetContext.class)


	private static final String cstActionCaseId = "caseId";
	private static final String cstActionProcessDefinitionId = "processDefinitionId";
	private static final String cstActionIsCaseArchived = "isCaseArchived";
	private static final String cstActionTaskId = "taskId";
	private static final String cstActionisTaskArchived = "isTaskArchived";

	
	// a Case has multiple access : a ProcessInstance or a ArchiveProcessInstance, a TaskInstance or an ArchiveTaskInstance...
	
	private static class ContextCaseId {
		Long taskInstanceId = null;
		Long processInstanceId = null;
	
		ProcessInstance processInstance=null;
		ActivityInstance activityInstance = null;
		ArchivedProcessInstance archivedProcessInstance = null;
		ArchivedActivityInstance archivedActivityInstance=null;
		
		public Long getProcessDefinitionId()
		{
			if ( processInstance!=null)
				return processInstance.getProcessDefinitionId();
			if (archivedProcessInstance!=null)
				return archivedProcessInstance.getProcessDefinitionId();
			return null;
		}
		
		public String trace()
		{
			String trace="ContextCaseid:";
			trace += (processInstance!=null ? "ProcessInstance[Open-"+processInstance.getId()+"],":"")
			trace += (archivedProcessInstance!=null ? "ProcessInstance[Archived-"+archivedProcessInstance.getId()+"/"+archivedProcessInstance.getSourceObjectId() +"],":"")
			trace += (activityInstance!=null ? "ActivityInstance[Active-"+activityInstance.getId()+"],":"")
			trace += (archivedActivityInstance!=null ? "ActivityInstance[Archived-"+archivedActivityInstance.getId()+"],":"");
			return trace;
		}
		
	}
	 
	 
	@Override
	RestApiResponse doHandle(HttpServletRequest request, RestApiResponseBuilder responseBuilder, RestAPIContext context) {
		// To retrieve query parameters use the request.getParameter(..) method.
		// Be careful, parameter values are always returned as String values

		// Here is an example of how you can retrieve configuration parameters from a properties file
		// It is safe to remove this if no configuration is required
		Map<String,Object> rootResult = new HashMap<String,Object>();
		DataInstance contextData=null;
		String sourceContextData="";
		String contextDataSt = null;
		boolean isLog=false;
		Boolean isLogFromParameter=null;
		logger.info("=================== GetContext RESTAPI");

		try
		{
			APIClient apiClient = context.apiClient;
			ProcessAPI processAPI = context.apiClient.processAPI;
			BusinessDataAPI businessDataAPI = context.apiClient.businessDataAPI;
			ContextCaseId contextCaseId = new ContextCaseId();
			
			try
			{
				isLogFromParameter = Boolean.valueOf( request.getParameter("log"));
				isLog = isLogFromParameter;
			}
			catch(Exception e) {}

			//----------------- get the perimeter (taskid or processInstanceId)
			try
			{
				contextCaseId.taskInstanceId = Long.valueOf( request.getParameter("taskId"));
				ActivityInstance activityInstance = processAPI.getActivityInstance( contextCaseId.taskInstanceId);
				contextCaseId.processInstanceId = activityInstance.getParentContainerId();
			} catch(Exception e ) {};

			if (contextCaseId.processInstanceId == null) {
				try
				{
					contextCaseId.processInstanceId = Long.valueOf( request.getParameter("caseId"));
				} catch(Exception e ) {};
			}

			if (contextCaseId.processInstanceId == null)
			{
				logError( rootResult, "parameter [taskId] or [caseId] required");
				return;
			}


			// ------------------ retrieve correct information
			// if the processinstance exist ? The task Id ?
			
			try
			{
				
				contextCaseId.processInstance = processAPI.getProcessInstance( contextCaseId.processInstanceId);
				if (contextCaseId.taskInstanceId !=null)
					contextCaseId.activityInstance = processAPI.getActivityInstance( contextCaseId.taskInstanceId);
			}
			catch(Exception e)
			{
				// logRest( isLog, "No processinstance found by ["+ contextCaseId.processInstanceId+"] : "+e.toString() );				
			}
			// same with archived... yes, in Bonita, class are different...
			try
			{
				if (contextCaseId.processInstance ==null)
				contextCaseId.archivedProcessInstance = processAPI.getFinalArchivedProcessInstance( contextCaseId.processInstanceId);
				if (contextCaseId.taskInstanceId !=null && contextCaseId.taskInstanceId == null)
					contextCaseId.archivedActivityInstance = processAPI.getArchivedActivityInstance( contextCaseId.taskInstanceId);
			}
			catch(Exception e)
			{
				// logRest( isLog, "No ArchivedProcessinstance found by ["+contextCaseId.processInstanceId+"] : "+e.toString() );
			}
			if (contextCaseId.processInstance == null && contextCaseId.archivedProcessInstance == null)
			{
				rootResult.put("caseId", contextCaseId.processInstanceId);
				logError(rootResult, "caseId unknown");
				return;
			}
			if (contextCaseId.taskInstanceId != null && contextCaseId.activityInstance==null && contextCaseId.archivedActivityInstance==null)
			{
				rootResult.put("caseId", contextCaseId.processInstanceId);
				rootResult.put("taskId", contextCaseId.taskInstanceId);
				logError(rootResult, "taskId unknown");
				return;
			}

			
			sourceContextData +=contextCaseId.trace();
			
			//----------------------- get the pilot
			try
			{
				if (contextCaseId.taskInstanceId !=null)
				{
					contextData = processAPI.getActivityDataInstance("context", contextCaseId.taskInstanceId);
					contextDataSt = contextData.getValue();
					sourceContextData+="ActivityDataInstance[context] value="+contextData.getValue();
				}
			} catch(DataNotFoundException dnte ) {}

			if (contextData == null)
			{
				try
				{
					contextData = processAPI.getProcessDataInstance("globalcontext", contextCaseId.processInstanceId);
					contextDataSt = contextData.getValue();
					sourceContextData+="ProcessDataInstance[globalcontext] value="+contextData.getValue();
				} catch(DataNotFoundException dnte ) {}
			}
			if (contextData == null)
			{
				contextDataSt = "{ \"*\" : \"all\",";
				contextDataSt += ", \""+cstActionCaseId+"\" : \""+cstActionCaseId+"\"";
				contextDataSt += ", \""+cstActionProcessDefinitionId+"\" : \""+cstActionProcessDefinitionId+"\"";
				contextDataSt += ", \""+cstActionIsCaseArchived+"\" : \""+cstActionIsCaseArchived+"\"";
				contextDataSt += ", \""+cstActionTaskId+"\" : \""+cstActionTaskId+"\"";
				contextDataSt += ", \""+cstActionisTaskArchived+"\" : \""+cstActionisTaskArchived+"\"";
				contextDataSt += "}";


				sourceContextData+="Default value="+contextDataSt;
			}


			logRest( isLog, "SourceContextData = "+sourceContextData);
			if (isLog)
			{
				rootResult.putAt("sourcecontextdata", sourceContextData);
			}
			//--------------- return the content
			JsonSlurper slurper = new JsonSlurper();
			Object contextDataMap = slurper.parseText(contextDataSt);
			if (contextDataMap == null )
			{
				logError(rootResult, "The JSON information is missing : "+sourceContextData);
			}
			else if (! contextDataMap instanceof Map)
			{
				logError( rootResult,  "Local Variable [context] must be a MAP");
			}
			else
			{
				// decode the Log
				if (isLogFromParameter==null) {
					try
					{
						isLog = Boolean.valueOf( contextDataMap.get("RESTCONTEXTISLOG" ) );
					}
					catch( Exception e)
					{}
				}


				for (Object varName : contextDataMap.keySet())
				{
					Object varAction = contextDataMap.get( varName );
					logRest(isLog, "Loop Get variable["+varName+"] / action["+varAction+"]");

					if (varName.equals("*"))
					{
						Long instanceForBdm = null;
						//------------ active part
						if (contextCaseId.processInstance!=null)
						{
							instanceForBdm = contextCaseId.processInstance.getId();
							List<DataInstance> listDataInstance = processAPI.getProcessDataInstances(contextCaseId.processInstance.getId(), 0,1000);
							for (DataInstance data : listDataInstance)
							{
								completeValue( rootResult, data.getName(), contextCaseId, apiClient, (Map<String,Object>) contextDataMap, isLog);
							}
						}
						if (contextCaseId.activityInstance!=null)
						{
							List<DataInstance> listDataInstance = processAPI.getActivityDataInstances(contextCaseId.activityInstance.getId(), 0,1000);
							for (DataInstance data : listDataInstance)
							{
								completeValue(rootResult, data.getName(), contextCaseId, apiClient, (Map<String,Object>) contextDataMap, isLog);
							}
						}
						// ----- archived part
						if (contextCaseId.archivedProcessInstance!=null)
						{
							instanceForBdm = contextCaseId.archivedProcessInstance.getId();
							List<ArchivedDataInstance> listDataInstance = processAPI.getArchivedProcessDataInstances(contextCaseId.archivedProcessInstance.getSourceObjectId(), 0,1000);
							for (ArchivedDataInstance data : listDataInstance)
							{
								completeValue( rootResult, data.getName(), contextCaseId, apiClient, (Map<String,Object>) contextDataMap, isLog);
							}
						}
						if (contextCaseId.archivedActivityInstance!=null)
						{
							List<ArchivedDataInstance> listDataInstance = processAPI.getArchivedActivityDataInstances(contextCaseId.archivedActivityInstance.getSourceObjectId(), 0,1000);
							for (ArchivedDataInstance data : listDataInstance)
							{
								completeValue( rootResult, data.getName(), contextCaseId, apiClient, (Map<String,Object>) contextDataMap, isLog);
							}
						}

						// logRest(isLog, "Search BDM with processInstanceId=["+contextCaseId.processInstanceId+"] instanceForBdm="+instanceForBdm);
						
						for (BusinessDataReference businessData : context.apiClient.businessDataAPI.getProcessBusinessDataReferences(contextCaseId.processInstanceId, 0,1000))
						{
							logRest(isLog, "Loop Get BDM["+businessData.getName()+"] / type["+businessData.getType()+"]");

							completeValue(rootResult, businessData.getName(),  contextCaseId, apiClient, (Map<String,Object>) contextDataMap, isLog);
						}


					}
					else if (cstActionCaseId.equals(varAction)) {
						rootResult.put(varName, contextCaseId.processInstanceId);
						// logRest(isLog,"cstActionCaseId :  new Result["+rootResult+"]");
					}

					else if (cstActionProcessDefinitionId.equals(varAction))
						rootResult.put( varName, contextCaseId.getProcessDefinitionId());


					else if (cstActionIsCaseArchived.equals(varAction))
						rootResult.put( varName, contextCaseId.processInstance==null );

					else if (cstActionTaskId.equals(varAction))
						rootResult.put( varName, contextCaseId.taskInstanceId);

					else if (cstActionisTaskArchived.equals(varAction))
						rootResult.put( varName, contextCaseId.activityInstance == null);
					else
					{
						completeValue( rootResult, varName, contextCaseId, apiClient, (Map<String,Object>) contextDataMap, isLog);
					}

				} // end of list
			}
			logRest( isLog, "Final rootResult "+rootResult.toString())

		} catch(DataNotFoundException dnte )
		{
			logError( rootResult, "Expect [context] or [globalcontext] variable to pilot what to search");
		}
		catch (JsonException je)
		{
			logError( rootResult,"Bad JSON "+sourceContextData+" : "+je.toString());
		}
		catch(Exception e )
		{
			StringWriter sw = new StringWriter();
			e.printStackTrace(new PrintWriter(sw));
			String exceptionDetails = sw.toString();
			logError( rootResult, e.toString()+" at "+exceptionDetails);

		}
		finally {
			logger.info("=================== End GetContext RESTAPI");

			// Send the result as a JSON representation
			// You may use buildPagedResponse if your result is multiple
			return buildResponse(responseBuilder, HttpServletResponse.SC_OK, new JsonBuilder(rootResult).toPrettyString())
		}
	}

	/**
	 * Build an HTTP response.
	 *
	 * @param  responseBuilder the Rest API response builder
	 * @param  httpStatus the status of the response
	 * @param  body the response body
	 * @return a RestAPIResponse
	 */
	RestApiResponse buildResponse(RestApiResponseBuilder responseBuilder, int httpStatus, Serializable body) {
		return responseBuilder.with {
			withResponseStatus(httpStatus)
			withResponse(body)
			build()
		}
	}

	/**
	 * Returns a paged result like Bonita BPM REST APIs.
	 * Build a response with content-range data in the HTTP header.
	 *
	 * @param  responseBuilder the Rest API response builder
	 * @param  body the response body
	 * @param  p the page index
	 * @param  c the number of result per page
	 * @param  total the total number of results
	 * @return a RestAPIResponse
	 */
	RestApiResponse buildPagedResponse(RestApiResponseBuilder responseBuilder, Serializable body, int p, int c, long total) {
		return responseBuilder.with {
			withAdditionalHeader(HttpHeaders.CONTENT_RANGE,"$p-$c/$total");
			withResponse(body)
			build()
		}
	}


	/**
	 * search the variable
	 * @param rootResult : the rootResult to complete.
	 * @param varName : the name of the variable to describe
	 * @param processInstanceId
	 * @param taskInstanceId
	 */
	private void completeValue( Map<String,Object> rootResult,
			String varName,
			ContextCaseId contextCaseId,
			APIClient apiClient,
			Map<String,Object> contextDataMap,
			boolean isLog)
	{

		ProcessAPI processAPI = apiClient.processAPI;
		BusinessDataAPI businessDataAPI = apiClient.businessDataAPI;

		logger.info("completeValue: Get variable["+varName+"]");

		
		if (contextCaseId.processInstance != null)
			try
			{
				DataInstance dataInstance = processAPI.getProcessDataInstance(varName.toString(), contextCaseId.processInstance.getId() );
				logRest( isLog, "completeValue: Get variable["+varName+"] is a PROCESSDATA : ["+dataInstance.getValue()+"]");	
				rootResult.put(dataInstance.getName(), dataInstance.getValue());
				return;
			} catch (DataNotFoundException dnte) {};
		
		if (contextCaseId.activityInstance != null)
			try
			{
				// logger.info("Try get localvariable["+varName+"]");
				DataInstance dataInstance = processAPI.getActivityDataInstance(varName.toString(), contextCaseId.activityInstance.getId() );
				logRest( isLog, "completeValue: Get variable["+varName+"] is a ACTIVITYDATA: ["+dataInstance.getValue()+"]");
				rootResult.put(dataInstance.getName(), dataInstance.getValue());
				return;
			} catch (DataNotFoundException dnte) {};
		
		if (contextCaseId.archivedProcessInstance != null)
			try
			{
			logRest( isLog, "completeValue: search variable["+varName+"] in getArchivedProcessDataInstance");
				ArchivedDataInstance archivedDataInstance = processAPI.getArchivedProcessDataInstance (varName.toString(), contextCaseId.archivedProcessInstance.getSourceObjectId() );
				logRest( isLog, "completeValue: Get variable["+varName+"] is a ARCHIVEDPROCESSDATA : ["+archivedDataInstance.getValue()+"]");

				rootResult.put(archivedDataInstance.getName(), archivedDataInstance.getValue());
				return;
			} catch (ArchivedDataNotFoundException dnte) {};
		
		if (contextCaseId.archivedActivityInstance != null)
		{
			
			try
			{
				logRest( isLog, "completeValue: search variable["+varName+"] in getArchivedActivityDataInstance");
				ArchivedDataInstance archivedDataInstance = processAPI. getArchivedActivityDataInstance( varName.toString(), contextCaseId.archivedActivityInstance.getSourceObjectId() );
				logRest( isLog, "completeValue: Get variable["+varName+"] is a ARCHIVEDPROCESSDATA : ["+archivedDataInstance.getValue()+"]");
	
				rootResult.put(archivedDataInstance.getName(), archivedDataInstance.getValue());
				return;
			} catch (ArchivedDataNotFoundException dnte) {};
		}
	
		
		
		// Business data ?
		try
		{
			logger.info("completeValue.1: Try getProcessDataReference["+varName+"] withProcessinstanceId["+contextCaseId.processInstanceId+"]");

			BusinessDataReference businessData = businessDataAPI.getProcessBusinessDataReference( varName, contextCaseId.processInstanceId);
			if (businessData==null)
			{
				logger.info("completeValue: not a BusinessDataReference ["+varName+"]");
			}
			else
			{
				// logger.info("completeValue.2: Get Business Reference ["+businessData.getName()+"]");

				// the result is maybe a HASHMAP or a LIST<HASMAP>
				Object resultBdm = null;
				boolean isMultiple=false;
				List<Long> listStorageIds = new ArrayList<Long>();
				if (businessData instanceof MultipleBusinessDataReference)
				{
					// this is a multiple data
					resultBdm = new ArrayList<HashMap<String,Object>>();
					isMultiple=true;
					logger.info("completeValue.3 Get MULTIPLE Business Reference ["+businessData.getName()+"] : type["+businessData.getType()+"]");
					listStorageIds.addAll( ((MultipleBusinessDataReference) businessData).getStorageIds());
				}
				if (businessData instanceof SimpleBusinessDataReference)
				{
					resultBdm = new HashMap<String,Object>();
					isMultiple=false;
					logger.info("completeValue.3: Get SIMPLE Business Reference ["+businessData.getName()+"] : type["+businessData.getType()+"]");
					listStorageIds.addAll( ((SimpleBusinessDataReference) businessData).getStorageId());
				}
				// logger.info("completeValue.3bis : Set ["+resultBdm+"] in result");

				rootResult.put( businessData.getName(), resultBdm);

				String classDAOName = businessData.getType()+"DAO";
				// logger.info("completeValue.4: Get Business Reference ["+businessData.getName()+"] it's a BDM-type["+businessData.getType()+"] classDao=["+classDAOName+"]");

				Class classDao = Class.forName( classDAOName );
				if (classDao==null)
				{
					// a problem here...
					logger.info("completeValue.5:>>>>>>>>>>>>>>>>>>>>  DaoClass ["+classDAOName+"] not Found");
					return;
				}
				// logger.info("completeValue.5:classDao Loaded ["+classDao.getName()+"]");


				BusinessObjectDAO dao;

				dao = apiClient.getDAO( classDao );

				// logger.info("completeValue.6:Dao loaded : dao["+ dao +"]");

				// now, check each BDM
				for (Long storageId : listStorageIds)
				{
					HashMap saveOneBdm = null;
					if (isMultiple)
					{
						saveOneBdm = new HashMap<String,Object>();
						resultBdm.add( saveOneBdm );
					}
					else
						saveOneBdm = resultBdm;

					// logger.info("completeValue.7: Get Business Reference ["+businessData.getName()+"] : type["+businessData.getType()+"] storageId["+storageId+"]");

					Entity dataBdmEntity = dao.findByPersistenceId(storageId);
					if (dataBdmEntity==null)
					{
						logError( rootResult, "The BDM variable["+businessData.getName()+"] storageId["+storageId+"] does not exist anymore " );
						return;
					}
					logger.info("completeValue.8: Got the BdmEntity");


					Class classBdmEntity= dataBdmEntity.getClass();
					logger.info("completeValue.9: got the class["+classBdmEntity.getName()+"]");

					// Start the recursive
					// example: variable is summerOrder : {}
					// Bdm is summerOrder -> Lines -> Ticket
					// saveOneBdm : this is the local level at this moment
					// ContextDataMap.get("summerorder") give the context to work (example
					// "summerOrder" : {
					//              "name": "data",
					//              " ticket": "*",
					//              "lines" : {  "linename" : "data",
					//                           "ticket" : { "solicitante" : "data" },
					//				         	 "price":"data"
					//	  		    }
					// }

					loadBdmVariableOneLevel(rootResult, saveOneBdm, dataBdmEntity, contextDataMap.get(varName), isLog );


				}
			}
			// def dao = context.apiClient.getDAO(MyDao.class)
			// def data= dao.findByPersistenceId(ref.storageId)
		} catch (Exception e) {
			logger.info("Error during get Business Data Information: "+e.toString());

		};

		return;
	}



	// load recursively the BDM Variable
	/*
	 * 
	 * 
	 * saveLocalLevel : attributes are save in this level
	 * dataBdmEntity is the current variable.
	 * contextLocalLevel is the current level of context to apply
	 * Ex : 
	 * 
	 * data: summerOrder
	 * Context : {
	 "name": "data",
	 "ticket": "*",
	 "lines" : {  "linename" : "data",
	 "ticket" : { "solicitante" : "data" },
	 "price":"data"
	 }
	 * We run all the different method.
	 * getName() ==> name is reference, save it
	 * getVendor() ==> vendor is not referenced, skip it
	 * getTicket() is a BDM so get ticket : referenced, then call recursively. To say "*" then the sub context is NULL
	 * getLines() is a BDM : call recursively given { "linename..." as the sub context} 
	 */
	private void loadBdmVariableOneLevel( Map<String,Object> rootResult,
			   Map<String,Object> saveLocalLevel,
			Entity dataBdmEntity,
			Map<String,Object> contextLocalLevel,
			boolean isLog)
	{
		Class classBdmEntity= dataBdmEntity.getClass();
		logger.info("completeValue.10a ---------loadBdmVariableOneLevel class["+classBdmEntity.getName()+"] contextLocalLevel["+contextLocalLevel.toString()+"]");
		
		Method[] listMethods= classBdmEntity.getMethods();

		//	logger.info("Field= "+listFields+" Methods="+listMethods);
		for (Method method : listMethods)
		{
			try
			{
				// logger.info("completeValue.10.a method["+method.getName()+"]");

				if (method.getName().startsWith("get") && method.getParameterTypes().length == 0
				&& ! "getClass".equals(method.getName())
				&& ! "getPersistenceVersion".equals(method.getName())
				&& ! "getHandler".equals(method.getName()) )
				{
					// call it !
					// logger.info("method=["+method.getName()+"]");

					Object value = method.invoke(dataBdmEntity, new Object[0]);
					// logger.info("completeValue.10b method["+method.getName()+"] Result=["+value+"]");
					String nameAttribute = method.getName();

					nameAttribute= nameAttribute.substring(3); // getInvoice => Invoice
					nameAttribute = nameAttribute.substring(0,1).toLowerCase()+nameAttribute.substring(1);

					// ok, the context pilot now
					boolean keepIt=true;
					if (contextLocalLevel!=null)
					{
						Object contextInfo = contextLocalLevel.get(nameAttribute);
						keepIt = contextInfo != null;
					}
					logger.info("completeValue.10b method["+method.getName()+"] nameAttribut["+nameAttribute+"] Result=["+value+"] keepIt="+keepIt+" Entity ? "+(value!=null && value instanceof Entity)+" classValue=["+(value !=null ? value.getClass().getName() : "null")+"]");
					

					if (!keepIt)
						continue;

					// is that a BDM ? Attention, 2 case : a Entity or a List of Entity (Bdm can be multiple)
					boolean isABdm=false;
					if (value!=null)
					{
						if (value instanceof Entity)
							isABdm=true;
						if (value instanceof List)
						{
							if (((List) value).size()>0)
							{
								Object firstValue= ((List) value).getAt(0);
								isABdm = firstValue instanceof Entity;
								logger.info("completeValue.10c Value is a list firstValue=["+firstValue+"]");
							}
						}
					}	

					if (isABdm)
					{
						logger.info("completeValue.10d SubChild detected");

						Object contextInfo = contextLocalLevel== null ? null: contextLocalLevel.get(nameAttribute);
						if (contextInfo instanceof String && "*".equals(contextInfo))
							contextInfo=null;
						logger.info("completeValue.10e SubChild contextInfo["+contextInfo+"]");

						// Ok, this is a Entity or a list of Entity. So, we have to create a Map or a List of Map
						if (value instanceof Entity)
						{
							Map<String,Object> bdmChild = new HashMap<String,Object>();
							saveLocalLevel.put(nameAttribute, bdmChild);
							loadBdmVariableOneLevel(rootResult, bdmChild, value, contextInfo, isLog )
						}
						if (value instanceof List)
						{
							List valueList = (List) value;
							List<Map<String,String>> listBdmChild=new ArrayList();
							saveLocalLevel.put(nameAttribute, listBdmChild);
							for ( Object valueInList : valueList )
							{
								Map<String,Object> bdmChild = new HashMap<String,Object>();
								listBdmChild.add( bdmChild );
								loadBdmVariableOneLevel(rootResult, bdmChild, valueInList, contextInfo, isLog )
							}
							
						}
					}
					else
						saveLocalLevel.put(nameAttribute, value);

					logger.info("completeValue.10c saveOneBdm ="+saveLocalLevel.toString());

				}
			}
			catch( Exception e)
			{
				logError( rootResult, "Error during exploring the Bdm variable ["+dataBdmEntity.getClass().getName()+"] : "+e.toString() );
			}
		}

	}

	private void logRest( boolean isLog, String logExplanation)
	{
		if (isLog)
			logger.info("com.bonitasoft.rest.context: "+logExplanation);
	}


	
	// report an error
	private void logError(Map<String,Object> rootResult, String logExplanation )
	{
		logger.error(logExplanation);
		String error = rootResult.get("error");
		if (error!=null)
			error+=";"+logExplanation;
		else
			error = logExplanation;
		rootResult.put("error", logExplanation);
	}
}
