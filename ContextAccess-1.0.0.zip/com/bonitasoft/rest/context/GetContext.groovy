package com.bonitasoft.rest.context;

import groovy.json.JsonBuilder
import groovy.json.JsonException;
import groovy.json.JsonSlurper;

import javax.servlet.http.HttpServletRequest
import javax.servlet.http.HttpServletResponse

import org.apache.http.HttpHeaders
import org.bonitasoft.engine.api.ProcessAPI;
import org.bonitasoft.engine.bpm.data.DataInstance;
import org.bonitasoft.engine.bpm.data.DataNotFoundException;
import org.bonitasoft.engine.bpm.flownode.ActivityInstance;
import org.bonitasoft.web.extension.ResourceProvider
import org.bonitasoft.web.extension.rest.RestApiResponse
import org.bonitasoft.web.extension.rest.RestApiResponseBuilder
import org.slf4j.Logger
import org.slf4j.LoggerFactory




import com.bonitasoft.web.extension.rest.RestAPIContext
import com.bonitasoft.web.extension.rest.RestApiController

class GetContext implements RestApiController {

    private static final Logger logger = LoggerFactory.getLogger(GetContext.class)

    @Override
    RestApiResponse doHandle(HttpServletRequest request, RestApiResponseBuilder responseBuilder, RestAPIContext context) {
        // To retrieve query parameters use the request.getParameter(..) method.
        // Be careful, parameter values are always returned as String values

        // Here is an example of how you can retrieve configuration parameters from a properties file
        // It is safe to remove this if no configuration is required
        Map<String,Object> result = new HashMap<String,Object>();
		DataInstance contextData=null;
		String sourceContextData="";
		String contextDataSt = null;
        try
		{
			ProcessAPI processAPI = context.apiClient.processAPI;
			
			//----------------- get the perimeter (taskid or processid)
			Long taskId = null;
			Long processId = null;
			try 
			{
				taskId = Long.valueOf( request.getParameter("taskId"));
				ActivityInstance activityInstance = processAPI.getActivityInstance(taskId);
				processId = activityInstance.getParentContainerId();
			} catch(Exception e ) {};
		
			if (processId == null) {
				try
				{
					processId = Long.valueOf( request.getParameter("caseId"));
				} catch(Exception e ) {};
			}
			
			if (processId == null)
			{
				result.put("error", "parameter [taskId] or [caseId] required");
				return;
			}

			
			//----------------------- get the pilot
			
			try
			{
				if (taskId !=null)
				{
					contextData = processAPI.getActivityDataInstance("context", taskId);
					contextDataSt = contextData.getValue();
					sourceContextData="ActivityDataInstance[context] value="+contextData.getValue();
				}
				
			} catch(DataNotFoundException dnte ) {}

			if (contextData == null)
			{
				try
				{
					contextData = processAPI.getProcessDataInstance("globalcontext", processId);
					contextDataSt = contextData.getValue();
					sourceContextData="ProcessDataInstance[globalcontext] value="+contextData.getValue();
				} catch(DataNotFoundException dnte ) {}
			}
			if (contextData == null)
			{
				contextDataSt = "{ \"*\" : \"all\" }";
				sourceContextData="Default value="+contextDataSt;
			}
			

			
			//--------------- return the content
			JsonSlurper slurper = new JsonSlurper();
			Object contextDataJson = slurper.parseText(contextDataSt);
			if (contextDataJson == null )
			{
				result.put("error", "The JSON information is missing : "+sourceContextData);
			}
			else if (! contextDataJson instanceof Map)
			{
				result.put("error", "Local Variable [context] must be a MAP");
			}
			else
			{
				for (Object varName : contextDataJson.keySet())
				{
					Object varAction = contextDataJson.get("varName");
					logger.info("Get variable["+varName+"]");
				
					if (varName.equals("*"))
					{
						List<DataInstance> listDataInstance=null;
						// get all variables
						if (taskId!=null)
						{
							listDataInstance = processAPI.getActivityDataInstances(taskId, 0,1000);
							for (DataInstance data : listDataInstance)
							{
								completeValue(processAPI, result, data.getName(), varAction, processId, taskId);
							}
						}
						listDataInstance = processAPI.getProcessDataInstances(processId, 0,1000);
						for (DataInstance data : listDataInstance)
						{
							completeValue(processAPI, result, data.getName(), varAction, processId, taskId);
						}
						
					}
					else
					{
						completeValue(processAPI, result, varName, varAction, processId, taskId);
					}
					
				} // end of list
			}
			logger.info("Final result "+result.toString());
		} catch(DataNotFoundException dnte ) 
		{
			logger.error("com.bonitasoft.rest.context: no context variable found");
			result.put("error", "Expect [context] or [globalcontext] variable to pilot what to search");

		}	
		catch (JsonException je)
		{
			
			logger.error("com.bonitasoft.rest.context: Bad JSON "+sourceContextData+" : "+je.toString());
			result.put("error", "Bad JSON "+sourceContextData+" : "+je.toString());

		}
		catch(Exception e )
		{
			StringWriter sw = new StringWriter();
			e.printStackTrace(new PrintWriter(sw));
			String exceptionDetails = sw.toString();
			logger.error("com.bonitasoft.rest.context: error "+e.toString()+" at "+exceptionDetails);
			result.put("error", e.toString()+" at "+exceptionDetails);
			
		}
		finally {
	        // Send the result as a JSON representation
	        // You may use buildPagedResponse if your result is multiple
	        return buildResponse(responseBuilder, HttpServletResponse.SC_OK, new JsonBuilder(result).toPrettyString())
		}
    }

    /**
     * Build an HTTP response.
     *
     * @param  responseBuilder the Rest API response builder
     * @param  httpStatus the status of the response
     * @param  body the response body
     * @return a RestAPIResponse
     */
    RestApiResponse buildResponse(RestApiResponseBuilder responseBuilder, int httpStatus, Serializable body) {
        return responseBuilder.with {
            withResponseStatus(httpStatus)
            withResponse(body)
            build()
        }
    }

    /**
     * Returns a paged result like Bonita BPM REST APIs.
     * Build a response with content-range data in the HTTP header.
     *
     * @param  responseBuilder the Rest API response builder
     * @param  body the response body
     * @param  p the page index
     * @param  c the number of result per page
     * @param  total the total number of results
     * @return a RestAPIResponse
     */
    RestApiResponse buildPagedResponse(RestApiResponseBuilder responseBuilder, Serializable body, int p, int c, long total) {
        return responseBuilder.with {
            withAdditionalHeader(HttpHeaders.CONTENT_RANGE,"$p-$c/$total");
            withResponse(body)
            build()
        }
    }

	
	/**
	 * search the variable
	 * @param result
	 * @param varName
	 * @param varAction
	 * @param processId
	 * @param taskId
	 */
   private void completeValue(ProcessAPI processAPI, Map<String,Object> result, String varName, String varAction, Long processId, Long taskId)
   {
	   DataInstance dataListInstance=null;
	   try
	   {
		   dataListInstance = processAPI.getProcessDataInstance(varName.toString(), processId);
		   logger.info("Get variable["+varName+"] : ["+dataListInstance.getValue()+"]");
		   
		   result.put(dataListInstance.getName(), dataListInstance.getValue());
		   return;
	   } catch (DataNotFoundException dnte) {};
	   try
	   {
		   if (taskId!=null)
		   {
			   logger.info("Try get localvariable["+varName+"]");
			   dataListInstance = processAPI.getActivityDataInstance(varName.toString(), taskId);
			   logger.info("Get variable["+varName+"] : ["+dataListInstance.getValue()+"]");
			   result.put(dataListInstance.getName(), dataListInstance.getValue());
			   return;
		   }
	   } catch (DataNotFoundException dnte) {};
   
   }

}
